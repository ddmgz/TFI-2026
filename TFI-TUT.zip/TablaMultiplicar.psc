Algoritmo TablaMultiplicar
    Definir n, i Como Entero
    
    Escribir "Ingrese el n�mero para generar su tabla de multiplicar:"
    Leer n
    
    Para i <- 1 Hasta 20 Hacer
        Escribir n, " X ", i, " = ", (n * i)
    FinPara
FinAlgoritmo
