Algoritmo InteresSimple
    Definir capital, tiempo, interes, tasa Como Real
    
    // Tasa precargada (ejemplo: 5% anual)
    tasa <- 0.05 
    
    Escribir "--- C�lculo de Inter�s Simple ---"
    Escribir "La tasa de inter�s aplicada es del: ", (tasa * 100), "%"
    
    Escribir "Ingrese el capital:"
    Leer capital
    Escribir "Ingrese el tiempo:"
    Leer tiempo
    
    interes <- capital * tasa * tiempo
    
    Escribir "El inter�s simple calculado es: ", interes
FinAlgoritmo
