Algoritmo AdivinarNumero
    Definir secreto, intento, diferencia Como Entero
    
    secreto <- Azar(25) + 1
    intento <- 0
    
    Escribir "Se ha generado un n�mero aleatorio entre 1 y 25."
    Escribir "�Intenta adivinarlo!"
    
    Mientras intento <> secreto Hacer
        Escribir "Ingresa tu n�mero:"
        Leer intento
        
        Si intento = secreto Entonces
            Escribir "�Correcto! Has adivinado el n�mero."
        Sino
            // Se calcula la diferencia absoluta
            diferencia <- Abs(secreto - intento)
            
            Si diferencia <= 3 Entonces
                Escribir "Est�s cercano."
            Sino
                Escribir "Est�s alejado."
            FinSi
        FinSi
    FinMientras
FinAlgoritmo
