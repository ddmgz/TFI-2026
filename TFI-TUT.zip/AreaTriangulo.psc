Algoritmo AreaTriangulo
    Definir base, altura, area Como Real
    
    Escribir "Ingrese la base del tri�ngulo:"
    Leer base
    Escribir "Ingrese la altura del tri�ngulo:"
    Leer altura
    
    area <- (base * altura) / 2
    
    Escribir "El �rea del tri�ngulo es: ", area
FinAlgoritmo